<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package Codeigniter
 * @subpackage Template Engine Blade
 * @category Config
 * @author Agung Dirgantara <agungmasda29@gmail.com>
 */



/* End of file template_engine_blade.php */
/* Location : ./Codeigniter Template Engine Driver/config/template_engine_blade.php */